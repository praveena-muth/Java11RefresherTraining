package com.hlag.logisticsystem.test;

import com.hlag.logisticsystem.Base;
import com.hlag.logisticsystem.Derived;

public class Test {

	public static void main(String[] args) {
		Base derived = new Derived();
		derived.test();
	}


}
