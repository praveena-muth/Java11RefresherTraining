package com.hlag.logisticsystem;

import com.hlag.logisticsystem.dto.Package;

public class App {

	public static void main(String[] args) {
		Package package1 = Package.getInstance();
		Package package2 = Package.getInstance();
		System.out.println(package1.equals(package2)); // true
		System.out.println(package1.hashCode()); // true
		System.out.println(package2.hashCode()); // true
	}

}
