package com.hlag.logisticsystem.app;
import java.util.Optional;

import com.hlag.logisticsystem.exception.InvalidNameException;
import com.hlag.logisticsystem.service.UserService;
import com.hlag.logisticsystem.service.UserServiceImpl;
import com.hlag.user.entity.User;

public class App {

	public static void main(String[] args) throws InvalidNameException {
        UserService userService = UserServiceImpl.getInstance();
        
        // Simulating different actions
        String actionType = "ADD_USER"; // Example action type. Could be dynamically set (e.g., user input)

        // Simulate user creation
        User user = new User("Pravee", "Pr", "Muth", "hapag@gmail.com", "85483921");

				// Switch-case based on action type
				switch (actionType) {
					case "ADD_USER":
						// Add the user and check if it was successfully added
						User addedUser = userService.addUser(user);
						if (addedUser != null) {
							System.out.println("User added successfully: " + addedUser);
						} else {
							System.out.println("Failed to add user.");
						}
						break;

					case "GET_USER_BY_ID":
						// Retrieve user by ID and print if present
						Optional<User> optionalUser = userService.getUserById(user.getId().toString());
						if (optionalUser.isPresent()) {
							System.out.println("User found: " + optionalUser.get());
						} else {
							System.out.println("User not found.");
						}
						break;

					// case "DELETE_USER":
					// // Assume a delete user method exists (just for demonstration)
					// boolean deleteResult = userService.deleteUser(user.getId().toString());
					// if (deleteResult) {
					// System.out.println("User deleted successfully.");
					// } else {
					// System.out.println("Failed to delete user.");
					// }
					// break;

					default:
						System.out.println("Invalid action type: " + actionType);
						break;
				}
		}
	}