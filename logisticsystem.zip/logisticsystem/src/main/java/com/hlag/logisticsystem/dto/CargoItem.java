package com.hlag.logisticsystem.dto;


public class CargoItem {

	private double weight;
	private String dimensinons;
	private String type;

	public CargoItem(double weight, String dimensinons, String type) {
		this.weight = weight;
		this.dimensinons = dimensinons;
		this.type = type;
	}

	public double getWeight() {
		return weight;
	}

	public String getDimensinons() {
		return dimensinons;
	}

	public String getType() {
		return type;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public void setDimensinons(String dimensinons) {
		this.dimensinons = dimensinons;
	}

	public void setType(String type) {
		this.type = type;
	}

	// Method to calculate shipping cost based on weight
	public double calculateShippingCost() {
		double baseCost = 10.0; // currency
		double weightFactor = 1; // Cost factor based on weight ( 1 per kg)

		// Cost calculation based on weight
		double cost = baseCost + (weight * weightFactor);

		// Adjust cost based on type of cargo
		switch (type.toLowerCase()) {
			case "fragile":
				cost += 20.0;
				break;
			case "perishable":
				cost += 15.0;
				break;
			default:
				break;
		}
		return cost;

}

	public static void main(String[] args) {
		CargoItem item1 = new CargoItem(10, "20x15x10", "fragile");
		CargoItem item2 = new CargoItem(2, "5x5x5", "perishable");

		System.out.println("Shipping cost for item fragile" + item1.calculateShippingCost());
		System.out.println("Shipping cost for item perishable" + item2.calculateShippingCost());
	}
}