package com.hlag.logisticsystem.service;

import java.util.List;
import java.util.Optional;

import com.hlag.logisticsystem.repo.UserRepository;
import com.hlag.logisticsystem.repo.UserRepositoryImpl;
import com.hlag.user.entity.User;


public class UserServiceImpl implements UserService {

	private UserRepository userRepository = UserRepositoryImpl.getInstance();

	private static UserServiceImpl userServiceImpl;

	private UserServiceImpl() {

	}

	public static UserServiceImpl getInstance() {
		if (userServiceImpl == null) {
			userServiceImpl = new UserServiceImpl();
		}
		return userServiceImpl;
	}

	@Override
	public User addUser(User user) {
		return userRepository.addUser(user);
	}

	@Override
	public Optional<User> getUserById(String id) {
		return userRepository.getUserById(id);
	}

	@Override
	public Optional<List<User>> getUsers() {
		return userRepository.getUsers();
	}

	@Override
	public void deleteUser(String id) {
		userRepository.deleteUser(id);

	}

	@Override
	public User updateUser(String id, User user) {
		return userRepository.updateUser(id, user);
	}

}
