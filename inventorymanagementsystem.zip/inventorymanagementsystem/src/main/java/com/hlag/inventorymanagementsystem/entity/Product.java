package com.hlag.inventorymanagementsystem.entity;

import java.util.UUID;

import com.hlag.inventorymanagementsystem.exception.InvalidNameException;

public class Product {

	private static Product product;

	private UUID productId;

	private String productName;

	private String productDescription;

	private double productPrice;

	private int productQuantity;

	public Product() {
		// Default Constructor
	}

	public Product(

			String productName,
			String productDescription,
			double productPrice,
			int productQuantity) throws InvalidNameException {
		this.productId = UUID.randomUUID();
		this.productName = productName;
		this.productDescription = productDescription;
		setPrice(productPrice);
		setQuantity(productQuantity);
	}

	public void updateProduct(Product product) {
		this.productName = product.getProductName();
		this.productDescription = product.getProductDescription();
		this.productPrice = product.getProductPrice();
		this.productQuantity = product.getProductQuantity();
	}

	public static Product getInstance() {
		if (product == null) {
			product = new Product();
		}
		return product;
	}

	public UUID getProductId() {
		return productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public double getProductPrice() {
		return productPrice;
	}


	public int getProductQuantity() {
		return productQuantity;
	}

	public void setPrice(double price) {
		if (price >= 0) {
			this.productPrice = price;
		} else {
			throw new IllegalArgumentException("Price cannot be negative");
		}
	}

	public void setQuantity(int quantity) {
		if (quantity >= 0) {
			this.productQuantity = quantity;
		} else {
			throw new IllegalArgumentException("Quantity cannot be negative");
		}
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productDescription="
				+ productDescription + ", productPrice=" + productPrice + ", productQuantity=" + productQuantity + "]";
	}

}
