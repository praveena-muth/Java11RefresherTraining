package com.hlag.inventorymanagementsystem.repo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.hlag.inventorymanagementsystem.entity.Product;


public class InventoryRepositoryImpl implements InventoryRepository {

	private List<Product> productList = new ArrayList();

	private static InventoryRepositoryImpl inventoryRepositoryImpl;

	private InventoryRepositoryImpl() {

	}

	public static InventoryRepositoryImpl getInstance() {
		if (inventoryRepositoryImpl == null) {
			inventoryRepositoryImpl = new InventoryRepositoryImpl();
		}
		return inventoryRepositoryImpl;
	}

	@Override
	public Product addProduct(Product product) {
		return productList.add(product) ? product : null;
	}

	@Override
	public Optional<Product> getProductById(String id) {
		return productList.stream().filter(e -> e.getProductId().toString().equals(id)).findFirst();
	}


	@Override
	public void deleteProduct(String id) {
		productList.removeIf(e -> e.getProductId().toString().equals(id));

	}

	@Override
	public Product updateProduct(String id, Product product) {
		UUID userId = UUID.fromString(id);
		for (Product updateProduct : productList) {
			if (updateProduct.getProductId().equals(userId)) {
				productList.addAll(Arrays.asList(product));
				return product;
			}
		}
		return null;
	}

	@Override
	public Optional<List<Product>> getProducts() {
		return productList.isEmpty() ? Optional.empty() : Optional.of(new ArrayList<>(productList));
	}


}
