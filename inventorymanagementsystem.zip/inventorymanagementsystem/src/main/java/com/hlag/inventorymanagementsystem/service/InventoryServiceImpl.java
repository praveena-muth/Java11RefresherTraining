package com.hlag.inventorymanagementsystem.service;

import java.util.List;
import java.util.Optional;

import com.hlag.inventorymanagementsystem.entity.Product;
import com.hlag.inventorymanagementsystem.repo.InventoryRepository;
import com.hlag.inventorymanagementsystem.repo.InventoryRepositoryImpl;


public class InventoryServiceImpl implements InventoryService {

	private InventoryRepository inventoryRepository = InventoryRepositoryImpl.getInstance();

	private static InventoryServiceImpl inventoryServiceImpl;

	private InventoryServiceImpl() {

	}

	public static InventoryServiceImpl getInstance() {
		if (inventoryServiceImpl == null) {
			inventoryServiceImpl = new InventoryServiceImpl();
		}
		return inventoryServiceImpl;
	}

	@Override
	public Product addProduct(Product product) {
		return inventoryRepository.addProduct(product);
	}

	@Override
	public Optional<Product> getProductById(String id) {
		return inventoryRepository.getProductById(id);
	}

	@Override
	public Optional<List<Product>> getProducts() {
		return inventoryRepository.getProducts();
	}

	@Override
	public void deleteProduct(String id) {
		inventoryRepository.deleteProduct(id);

	}

	@Override
	public Product updateProduct(String id, Product product) {
		return inventoryRepository.updateProduct(id, product);
	}

}
