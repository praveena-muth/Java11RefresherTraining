package com.hlag.aircargosystem;


public interface PaymentProcessor {


	boolean processPayment(double amount);

	String paymentStatus();

}

