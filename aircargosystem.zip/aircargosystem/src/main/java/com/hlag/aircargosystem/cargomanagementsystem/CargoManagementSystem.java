package com.hlag.aircargosystem.cargomanagementsystem;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CargoManagementSystem {

	private List<Cargo> cargoList;

	public CargoManagementSystem() {
		this.cargoList = new ArrayList<>();
	}


	public void addCargo(Cargo cargo) {
		cargoList.add(cargo);
		System.out.println("Cargo added: " + cargo);
	}


	public boolean removeCargo(int cargoId) {
		Iterator<Cargo> iterator = cargoList.iterator();
		while (iterator.hasNext()) {
			Cargo cargo = iterator.next();
			if (cargo.getId() == cargoId) {
				iterator.remove();
				System.out.println("Cargo removed: " + cargo);
				return true;
			}
		}
		System.out.println("Cargo with ID " + cargoId + " not found.");
		return false;
	}


	public void displayCargo() {
		if (cargoList.isEmpty()) {
			System.out.println("No cargo items available.");
		} else {
			System.out.println("Cargo List:");
			for (Cargo cargo : cargoList) {
				System.out.println(cargo);
			}
		}
	}
}
