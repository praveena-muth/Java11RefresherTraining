package com.hlag.aircargosystem;


public class Test {

	public static void main(String[] args) {
		Cargo cargo = new Cargo(null, null, 0);
		cargo.test();
	}

}
