package com.hlag.aircargosystem;


public class ShippingPaymentProcessor  implements PaymentProcessor {

	String paymentStatus;

	public ShippingPaymentProcessor() {
		this.paymentStatus = "Processing Payment";
	}

	@Override
	public boolean processPayment(double amount) {
		System.out.println("Processing payment" + amount);
		return true;
	}

	@Override
	public String paymentStatus() {

		return paymentStatus;
	}

	}
	

