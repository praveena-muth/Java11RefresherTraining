package com.hlag.aircargosystem;


public class PaymentProcessorTest {

	public static void main(String[] args) {
		PaymentProcessor paymentProcessor = new ShippingPaymentProcessor();
		paymentProcessor.processPayment(100.0);
		System.out.println("Payment Status: " + paymentProcessor.paymentStatus());

	}
}
