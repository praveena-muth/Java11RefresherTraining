package com.testing.test;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

public class LambdaexpressionLambdaHasmap {

	public static void main(String[] args) {
		
		Map<String, Integer> map = new HashMap<>();
		map.put("A", 1);
		map.put("B", 2);

		demo();
		//forloop
		
		/*for (Map.Entry<String, Integer> entry : map.entrySet()) {
			System.out.println("Key: " + entry.getKey() + ",Value: " + entry.getValue());
		}*/
		
	    //Lambda expression
	
			map.forEach((k, v) -> {
	System.out.println("Key: " + k + ",Value: " + v);
        });

			// Lambda expression with functional interface

			/*	Function<String, Integer> function = x -> x.length();
				System.out.println(function.apply("PRAVEENA"));*/

}

public static void demo() {
	Function<String, Integer> function = x -> x.length();
	Function<Integer, Integer> function2 = x -> x * 2;

	int result = function.andThen(function2).apply("Praveena");
	System.out.println(result);

}
}
@FunctionalInterface
interface Iops {

	public int add(int a, int b);
}