package com.testing.test;

import java.util.stream.IntStream;

public class ThreadsDemo {

	public static void main(String[] args) {
		Runnable runnable = () -> {
			IntStream.range(1, 10).forEach((e) -> {
				try {
					Thread.sleep(1000);
					System.out.println("Thread name: " + Thread.currentThread().getName() + " - " + e);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
			});
		};

		Thread thread = new Thread(runnable);
		thread.start();
		Thread thread1 = new Thread(runnable);
		thread1.start();
		Thread thread2 = new Thread(runnable);
		thread2.start();

		// Thread.getAllStackTraces().forEach((k, v) -> {
		// System.out.println("Thread name: " + k);
		// });
	}
}
