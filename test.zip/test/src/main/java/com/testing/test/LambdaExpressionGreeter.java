package com.testing.test;


public class LambdaExpressionGreeter {

	public static void main(String[] args) {
	}
}

@FunctionalInterface
interface greeter {
	public String greet(String name);

}