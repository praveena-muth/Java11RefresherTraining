package com.testing.test;


public class LambdaexpressionAnonymous {
public static void main(String[] args) {


	I6 i6 = new I6() {

		@Override
		public boolean test() {
			System.out.println("Hello from test");
			return true;
		}

		@Override
		public void test2() {
			System.out.println("Hello from test2");
		}
	};
	i6.test2();

}
}

@FunctionalInterface
interface I6 {

	public boolean test();

	public default void test2() {
		System.out.println("hello from test3");
	}
}

class I6ipml implements I6 {

	@Override
	public boolean test() {
		System.out.println("hello from test");
		return true;
	}

	@Override
	public void test2() {
		System.out.println("hello from test2");

	}
}

