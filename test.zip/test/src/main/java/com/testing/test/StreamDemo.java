package com.testing.test;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamDemo {

	public static void main(String[] args) {
		List<String> words = Arrays.asList("apple", "banana", "orange", "dates");

		List<String> result = words.stream()
				.filter(e -> e.length() > 5)
				.map(e -> e.toUpperCase())
				.collect(Collectors.toList());

		result.stream().forEach(e -> System.out.println("Stream" + e));
		result.forEach(e -> System.out.println("foreach" + e));

		System.out.println("Result : " + result);
	}
}
