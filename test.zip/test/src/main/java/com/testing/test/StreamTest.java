package com.testing.test;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamTest {

	public static void main(String[] args) {



	List<String> words = Arrays.asList("apple", "banana", "orange", "dates");
	// List<String> result = new ArrayList();

	Long startTime = System.currentTimeMillis();
	List<String> result = words.stream()
			.filter(e -> e.length() > 5)
			.map(e -> e.toUpperCase())
			.collect(Collectors.toList());
	Long endTime = System.currentTimeMillis();
	System.out.println("Diffence : " + (startTime - endTime));
	System.out.println("result : " + result);
	
	
	long startTimeLoop = System.currentTimeMillis();
   List<String> resultLoop = new java.util.ArrayList<>();
   for (String word : words) {
       if (word.length() > 5) {
           resultLoop.add(word.toUpperCase());
       }
   }
		long endTimeLoop = System.currentTimeMillis();
   long durationLoop = endTimeLoop - startTimeLoop;

   System.out.println("Result using For-Loop: " + resultLoop);
		System.out.println("Time taken by For-Loop approach: " + durationLoop);
	
}
}