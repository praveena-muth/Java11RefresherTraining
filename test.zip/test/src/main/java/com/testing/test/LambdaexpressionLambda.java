package com.testing.test;


public class LambdaexpressionLambda {
public static void main(String[] args) {

	I7 i6 = () -> true;
	System.out.println(i6.test());
	i6.test2();

	I7 i7 = new I7() {

		@Override
		public boolean test() {
			System.out.println("Hello from test");
			return true;
		}

		@Override
		public void test2() {
			System.out.println("Hello from test2");
		}
	};
	i7.test2();

}
}

@FunctionalInterface
interface I7 {

	public boolean test();

	public default void test2() {
		System.out.println("hello from test3");
	}
}

class I7ipml implements I7 {

	@Override
	public boolean test() {
		System.out.println("hello from test");
		return true;
	}

	@Override
	public void test2() {
		System.out.println("hello from test2");

	}
}

