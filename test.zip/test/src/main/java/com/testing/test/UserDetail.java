package com.testing.test;

import java.util.UUID;

public class UserDetail {

	UUID userUUID;
	String userName;
	long userId;
	String firstName;
	String lastName;
	int contactNumber;
	String emailId;

	public UserDetail(
			String userName,
			long userId,
			String firstName,
			String lastName,
			int contactNumber,
			String emailId) {
		this.userName = userName;
		this.userId = userId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.contactNumber = contactNumber;
		this.emailId = emailId;
	}

	public UUID getUserUUID() {
		return UUID.randomUUID();
	}


	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}


	public long getUserId() {
		return userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(int contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public void setUserName(String userName) {
		if (userName != null && userName.length() <= 8) {
			this.userName = userName;
		} else {
			throw new IllegalArgumentException("Username must be exactly 8 characters long.");
		}
	}


}