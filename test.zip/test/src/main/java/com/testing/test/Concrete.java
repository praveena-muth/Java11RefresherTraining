package com.testing.test;


public class Concrete extends AbstractTest {

	@Override
	public void method8() {
		System.out.println("Concrete method8()");
	}

	@Override
	public void method9() {
		System.out.println("Concrete method9()");
	}

	public static void main(String[] args) {
		I1 i1 = new Concrete();
		i1.method1();

		I3 i3 = new Concrete();
		i3.method8();
	}
}
