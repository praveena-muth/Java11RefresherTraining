package com.testing.test;


public class BuilderExample {

	public static void main(String[] args) {
		// Building a shipment with all attributes
		Shipment shipment = new Shipment.ShipmentBuilder("New York", "Express", "2021-09-01").setTrackingNumber("123456")
				.setInsurance(true)
				.setGiftWrap(true)
				.build();
		System.out.println(shipment);

		// Building a shipment with mandatory attributes only
		Shipment shipment2 = new Shipment.ShipmentBuilder("Los Angeles", "Standard", "2021-09-02").build();
		System.out.println(shipment2);

	}

}
	class Shipment {

		private String destination;
		private String shipmentType;
		private String shippingDate;
		private String trackingNumber;
		private boolean insurance;
		private boolean giftWrap;

		// Private constructor to enforce object creation through Builder
	private Shipment(ShipmentBuilder builder) {
      this.destination = builder.destination;
      this.shipmentType = builder.shipmentType;
      this.shippingDate = builder.shippingDate;
      this.trackingNumber = builder.trackingNumber;
      this.insurance = builder.insurance;
      this.giftWrap = builder.giftWrap;
    }

		static class ShipmentBuilder {
			private String destination;
			private String shipmentType;
			private String shippingDate;
			private String trackingNumber;
			private boolean insurance;
			private boolean giftWrap;

			// Mandatory fields via constructor
			public ShipmentBuilder(String destination, String shipmentType, String shippingDate) {
				this.destination = destination;
				this.shipmentType = shipmentType;
				this.shipmentType = shippingDate;
			}

			// Optional fields via setters
			public ShipmentBuilder setTrackingNumber(String trackingNumber) {
				this.trackingNumber = trackingNumber;
				return this; // Return the builder instance for method chaining
			}

			public ShipmentBuilder setInsurance(boolean insurance) {
				this.insurance = insurance;
				return this;
			}

			public ShipmentBuilder setGiftWrap(boolean giftWrap) {
				this.giftWrap = giftWrap;
				return this;
			}

			// Build method to create the final Shipment object
			public Shipment build() {
				return new Shipment(this);
			}

		}


		@Override
		public String toString() {
			return "Shipment [destination=" + destination + ", shipmentType=" + shipmentType + ", shippingDate="
					+ shippingDate + ", trackingNumber=" + trackingNumber + ", insurance=" + insurance + ", giftWrap=" + giftWrap
					+ "]";

}
}

class Main {


}
