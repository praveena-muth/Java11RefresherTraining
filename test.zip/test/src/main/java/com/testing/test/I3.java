package com.testing.test;


public interface I3 {

	public void method8();

	public void method9();
}
