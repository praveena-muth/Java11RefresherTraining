package com.hlag.employee;

import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class EmployeeMain {

	public static void main(String[] args) {
		List<Employee> employee = Arrays.asList(
				new Employee("Alice", 60000, "IT", 30),
				new Employee("Bob", 45000, "HR", 25),
				new Employee("Charlie", 55000, "IT", 35),
				new Employee("David", 30000, "Finance", 40),
				new Employee("Eve", 70000, "IT", 29));

		Map<String, Double> filterEmployee = employee.stream()
				.filter(e -> e.getSalary() > 50000)
				.collect(Collectors.toMap(e -> e.name, e -> e.salary));

		System.out.println("Employee with salary greater than 50000 : " + filterEmployee);

		double totalSalary = employee.stream()
				.filter(e -> e.getSalary() > 50000)
				.map(Employee::getSalary)
				.reduce(0.0, Double::sum);
		System.out.println("Total salary of employees with salary greater than 50000 : " + totalSalary);

		List<Integer> numbers = IntStream.range(1, 10_000_000).boxed().collect(Collectors.toList());
		Instant start = Instant.now();
		long sequentialSum = numbers.stream().mapToLong(n -> (long) n * n).sum();
		Instant end = Instant.now();
		System.out
				.println("Sequential Sum: " + sequentialSum + ", Time: " + (end.toEpochMilli() - start.toEpochMilli()) + "ms");
	}
}
