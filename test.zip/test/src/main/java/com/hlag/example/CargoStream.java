package com.hlag.example;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class CargoStream {

	public static void main(String[] args) {

		List<Cargo> cargoList = Arrays.asList(
				new Cargo("Clothing", "Apparel", 50.00),
				new Cargo("Electronics", "Electrical", 10.00),
				new Cargo("Groceries", "Food", 20.00),
				new Cargo("Furniture", "Wood", 30.00));

		// Filter cargo items by type

		List<Cargo> listCargo = cargoList.stream().filter(c -> c.getType().equals("Wood")).collect(Collectors.toList());
		System.out.println("Wood Cargo: " + listCargo);

		// Sort cargo items by weight (ascending)
		List<Cargo> sortedList = cargoList.stream()
				.sorted(Comparator.comparingDouble(c -> c.getWeight()))
				.collect(Collectors.toList());
		System.out.println("Sorted By Weight:" + sortedList);

		// Count how many cargo items weigh more than 10kg
		long cargoCount = cargoList.stream().filter(c -> c.getWeight() > 10).count();
		System.out.println("Cargo Count:" + cargoCount);
	}
}
