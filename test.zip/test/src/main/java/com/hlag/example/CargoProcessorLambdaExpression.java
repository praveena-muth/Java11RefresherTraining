package com.hlag.example;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CargoProcessorLambdaExpression {
public static void main(String[] args) {
	List<String> cargo = Arrays.asList("Clothing", "Electronics", "Groceries", "Furniture");
	cargo.forEach(c -> System.out.println(c));
	
	Map<String, Integer> cargoMap = new HashMap<>();
	cargoMap.put("Clothing", 500);
	cargoMap.put("Electronics", 1000);
	cargoMap.put("Groceries", 2000);
	cargoMap.put("Furniture", 3000);

	cargoMap.forEach((k, v) -> {
		System.out.println("Cargo:" + k + ", Quantity:" + v);
	});
}
}

@FunctionalInterface
interface cargoProcess {
	public void processCargo(String cargo, int quantity);
}