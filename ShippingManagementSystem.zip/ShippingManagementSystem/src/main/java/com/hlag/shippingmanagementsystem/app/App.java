package com.hlag.shippingmanagementsystem.app;


public class App {

	public static void main(String[] args) {

	}
}
