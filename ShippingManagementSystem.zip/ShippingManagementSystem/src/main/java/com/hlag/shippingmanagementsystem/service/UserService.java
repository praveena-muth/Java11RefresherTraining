package com.hlag.shippingmanagementsystem.service;

import java.util.List;

import com.hlag.shippingmanagementsystem.entity.User;
import com.hlag.shippingmanagementsystem.repo.UserRepository;

public class UserService {

	private UserRepository userRepository = UserRepository.getInstance();
	private static UserService userService;

	private UserService() {
	}

	public static UserService getInstance() {
		if (userService == null) {
			userService = new UserService();
		}
		return userService;
	}

	public User add(User user) {
		return userRepository.add(user);
	}

	public User get(int id) {
		return userRepository.getId(id);
	}

	public void delete(int id) {
		userRepository.delete(id);
	}

	public void update(int id) {
		userRepository.update(id);
	}

	public List<User> getByUsers() {
		return userRepository.getByUsers();
	}

}

