package com.hlag.shippingmanagementsystem.repo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.hlag.shippingmanagementsystem.entity.Shipment;

public class ShipmentRepository {

	private List<Shipment> shipments = new ArrayList<>();

	private static ShipmentRepository shipmentRepository;

	private ShipmentRepository() {
	}

	public static ShipmentRepository getInstance() {
		if (shipmentRepository == null) {
			shipmentRepository = new ShipmentRepository();
		}
		return shipmentRepository;
	}

	public Shipment add(Shipment shipment) {
		boolean result = shipments.add(shipment);
		if (result) {
			shipments.add(shipment);
		}
		return null;
	}

	public Shipment getId(int id) {
		Optional<Shipment> shipment = shipments.stream().filter(p -> p.getId() == id).findFirst();
		return shipment.orElse(null);
	}

	public void delete(int id) {
		shipments.removeIf(e -> e.getId() == id);
	}

	public void update(int id) {
		shipments.stream().filter(p -> p.getId() == id).forEach(p -> p.setTrackingNumber("12345"));
	}

	public List<Shipment> getByShipments() {
		if (shipments.isEmpty()) {
			return new ArrayList<>();
		} else {
			return shipments;
		}
	}

}

